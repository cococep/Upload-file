/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ProgramDenganIDE;

/**
 * NAMA  : HERI FIRMANSAH
 * NIM   : A2.1900079
 * KELAS : TI-IC
 * @author Heri Firmansah
 */

public class Main {

    public static void main(String[] args){
        System.out.println("hello world");
    }
}
