/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg20.pkgif.statement;

/**
 * NAMA  : HERI FIRMANSAH
 * NIM   : A2.1900079
 * KELAS : TI-IC
 * @author Heri Firmansah
 */
public class IfStatement {

    public static void main (String[] args){

//        tutorial untuk if statement atau percabangan

        int a = 5;

        System.out.println("nilai = " + a);

        // ini adalah cabangnya

        if (a == 10){

            System.out.println("ini adalah jalur true");

        } else {

            System.out.println("ini adalah jalur false");

        }


        System.out.println("selesai");

    }
}
