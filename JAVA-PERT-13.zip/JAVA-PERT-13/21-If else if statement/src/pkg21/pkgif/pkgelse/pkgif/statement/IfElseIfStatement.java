/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg21.pkgif.pkgelse.pkgif.statement;

/**
 * NAMA  : HERI FIRMANSAH
 * NIM   : A2.1900079
 * KELAS : TI-IC
 * @author Heri Firmansah
 */
public class IfElseIfStatement {

    public static void main (String[] args){

        // tutorialif else if statement

        int a = 5;

        System.out.println("ini adalah awal program");

        // if else if statement

        if (a == 5){

            System.out.println("ini adalah aksi 1");

        } else if (a == 10) {

            System.out.println("ini adalah aksi 2");

        } else {

            System.out.println("ini adalah aksi default");

        }

        // akhir dari if else if statement

        System.out.println("ini adalah akhir program");


    }
}
